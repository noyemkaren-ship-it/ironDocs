import customtkinter as ctk

def init_root(name):
    global root
    root = ctk.CTk()
    root.title(name)

def label(text):
    label = ctk.CTkLabel(root, text=text)
    label.pack()

def close():
    root.mainloop()

init_root("app")
label("Hello")
close()