import time
import json
import requests
import subprocess
from build.lecser import *
import customtkinter as ctk
import matplotlib
from build.funcs import *

matplotlib.use('Agg')
url = "https://google.com"
save = 0
chek = 0
kayan = 0
code = ""
lex = True
root = None

shared_globals = {
    'print': print, 'int': int, 'str': str, 'float': float, 'len': len,
    'root': root, 'ctk': ctk,
}


def init_root(title: str):
    global root
    if root is None:
        root = ctk.CTk()
    root.title(title)
    root.geometry("400x300")
    root.deiconify()
    root.update()


def btn_click(text: str, command: str):
    global root
    if root is None:
        init_root("Iron App")

    def callback():
        if command.startswith("%p%"):
            python_command_run(f"%p%{command[3:]}")
        else:
            main_memory(command)

    btn = ctk.CTkButton(root, text=text, command=callback)
    btn.pack(pady=5)
    root.update()


def lable(text: str):
    global root
    if root is None:
        init_root("Iron App")
    name = ctk.CTkLabel(root, text=text)
    name.pack(pady=10)
    root.update()


def close():
    global root
    if root is not None:
        root.mainloop()


with open("scr/main.iron") as file:
    MEMORY_PEREMEN = []
    MEMORY_FUN_FILE = []


    def read(line):
        if (line.startswith("read ")):
            line = line[5:]
            values = input("[LOG]: ")
            MEMORY_PEREMEN.append({"key": line, "value": values})
            return values
        elif (line.startswith("int read ")):
            line = line[9:]
            try:
                values = int(input("[LOG (int)] -> "))
                MEMORY_PEREMEN.append({"key": line, "value": values})
                return values
            except ValueError:
                print("[ERROR] Нужно ввести число")
                return 0


    def add_peremen(line):
        if ("%=%" in line):
            key, value = line.split("%=%", maxsplit=1)
            key_clean = key.strip()
            value_clean = value.strip()
            if (value_clean.startswith('"') and value_clean.endswith('"')):
                value_clean = value_clean[1:-1]
            elif (value_clean.startswith("'") and value_clean.endswith("'")):
                value_clean = value_clean[1:-1]
            else:
                try:
                    value_clean = int(value_clean)
                except ValueError:
                    try:
                        value_clean = float(value_clean)
                    except ValueError:
                        pass
            MEMORY_PEREMEN.append({"key": key_clean, "value": value_clean})
            return value_clean


    def put_logic(line):
        if (line.startswith("put ")):
            clean_line = line[4:]
            found_value = find_in_memory(clean_line)
            if found_value != False:
                print(found_value)
                return found_value
            print(clean_line)
            return clean_line


    def find_in_memory(line):
        for per in MEMORY_PEREMEN:
            if (line == per["key"]):
                return per["value"]
        return False


    def add_fun(line):
        if (line.startswith("fun ")):
            clean_command = line[4:]
            print(f"[LOG]-> новая функция {clean_command}")
            if "%" in clean_command:
                name, value = clean_command.split("%", maxsplit=1)
                name = name.strip()
                value = value.strip()
                MEMORY_FUN_FILE.append({"name": name, "value": value})
                return name
            else:
                print("[ERROR] Неверный формат функции")


    def find_func(line):
        for funcs in MEMORY_FUN_FILE:
            if (line == funcs["name"]):
                value = funcs["value"].strip()
                if ("put" in value):
                    return put_logic(value)
                elif ("%=%" in value):
                    return add_peremen(value)
                elif ("req" in value):
                    return req_find(value)
                else:
                    print(f"[LOG] -> I dont know command {value}")
                    return None
        return None


    def req_find(line):
        if (line.startswith("req ")):
            link = line[4:].strip()
            found_link = find_in_memory(link)
            if found_link != False: link = found_link
            try:
                result = requests.get(link, timeout=5)
                return result.text
            except Exception as e:
                return f"[ERROR] Не удалось выполнить запрос: {e}"


    def reqs_command(line):
        if (line.startswith("reqs")):
            kolvo = input("Сколько вам нужно запросов: ")
            try:
                result = subprocess.run(["build/requests", url, kolvo], capture_output=True, text=True)
                print("--- Вывод C++ программы ---")
                print(result.stdout)
                if result.stderr: print("Ошибки:", result.stderr)
                print("---------------------------")
            except FileNotFoundError:
                print("[ERROR] Файл build/requests не найден.")


    def post_requests(line):
        if (line.startswith("preq ")):
            line = line[5:]
            try:
                urls, jsons = line.split("%=%", maxsplit=1)
                urls = urls.strip()
                jsons = json.loads(jsons)
                result = requests.post(urls, json=jsons, timeout=5)
                print(result.status_code)
                print(result.json())
                return result
            except Exception as e:
                print(f"[ERROR] POST request failed: {e}")
                return None


    def reqs_add_url(line):
        global url
        if (line.startswith("http")):
            print("[LOG]-> найден url")
            url = line.strip()
            return url


    def import_iron(line):
        if (line.startswith("import ")):
            filename = line[7:].strip()
            try:
                with open("scr/" + filename, "r", encoding="utf-8") as two_file:
                    for imported_line in two_file:
                        imported_line = imported_line.strip()
                        if not imported_line: continue
                        main_memory(imported_line)
            except FileNotFoundError:
                print(f"[ERROR] Файл {filename} не найден")


    def python_command_run(line):
        global shared_globals, root
        shared_globals['root'] = root
        shared_globals['MEMORY_PEREMEN'] = MEMORY_PEREMEN
        shared_globals['MEMORY_FUN_FILE'] = MEMORY_FUN_FILE
        command = line[3:].strip()
        try:
            exec(command, shared_globals)
        except Exception as e:
            print(f"[Python Error]: {e}")


    def main_memory(line):
        global save, lex
        if ("%=%" in line):
            add_peremen(line)
            return
        lec = Lecser(line)
        lec_result = lec.find()
        if not lec_result and not lex and kayan == 0:
            func_result = find_func(line)
            if func_result is None:
                print(f"[ERROR] Неизвестная команда: {line}")
            return

        if (save == 1):
            try:
                with open("scr/save.txt", "a", encoding="utf-8") as save_file:
                    save_file.write("\nновая строка\n")
                    if (line.startswith("memory")):
                        save_file.write(f"ПЕРЕМЕННЫЕ: {MEMORY_PEREMEN}\nФУНКЦИИ: {MEMORY_FUN_FILE}\n")
                    elif (line.startswith("put")):
                        result = put_logic(line)
                        if result: save_file.write(f"{result}\n")
                    elif (line.startswith("req")):
                        save_file.write(f"{req_find(line)}\n")
                    elif (line.startswith("math")):
                        save_file.write(f"Результат {mathik(line)}\n")
                    else:
                        func_result = find_func(line)
                        if func_result is None:
                            print(f"[ERROR] Неизвестная команда: {line}")
            except Exception as e:
                print(f"[ERROR] Save failed: {e}")
            save = 0
            return

        if (line.startswith("@save")):
            save = 1
        elif (line.startswith("init_root")):
            title = line[10:].strip() if len(line) > 9 else "Iron App"
            init_root(title)
        elif (line.startswith("import")):
            import_iron(line)
        elif (line.startswith("%p%")):
            python_command_run(line)
        elif (line.startswith("reqs")):
            reqs_command(line)
        elif (line.startswith("req ")):
            print("[LOG]-> ", req_find(line))
        elif (line.startswith("read")):
            read(line)
        elif (line.startswith("help")):
            print(LECSER)
        elif (line.startswith("btn ")):
            parts = line[4:].split("%", maxsplit=1)
            if len(parts) == 2:
                text = parts[0].strip()
                command = parts[1].strip()
                btn_click(text, command)
            else:
                print("[ERROR] Неверный формат btn")
        elif (line.startswith("http")):
            reqs_add_url(line)
        elif (line.startswith("put")):
            put_logic(line)
        elif (line.startswith("preq")):
            post_requests(line)
        elif (line.startswith("lbl ")):
            lable(text=line[4:])
        elif (line.startswith("close")):
            close()
        elif (line.startswith("sleep")):
            try:
                parts = line.split()
                seconds = int(parts[1]) if len(parts) > 1 else 5
                time.sleep(seconds)
            except:
                time.sleep(5)
        elif (line.startswith("memory")):
            print("ПЕРЕМЕННЫЕ:", MEMORY_PEREMEN)
            print("ФУНКЦИИ:", MEMORY_FUN_FILE)
        elif (line.startswith("fun")):
            add_fun(line)
        elif (line.startswith("math ")):
            mathik(line)
        elif (line.startswith("start")):
            start_iron(line)
        elif (line.startswith("lex_f")):
            lex = False
        elif (line.startswith("lex_s")):
            lex = True


    def while_in_iron(line):
        if (line.startswith("while e")):
            line = line[7:]
            try:
                kolvo, value = line.split("%", maxsplit=1)
                kolvo = int(kolvo)
                while (kolvo > 0):
                    main_memory(value)
                    kolvo -= 1
                    print(f"[LOG]-> осталось {kolvo}")
            except ValueError:
                print("[ERROR] Неверный формат while")


    def hard_if(line):
        global chek, ist
        if (line.startswith("if ")):
            chek = 0
            line = line[3:].strip()
            if ("=" in line and "==" not in line):
                line = line.replace("=", "==", 1)
            if ("==" in line):
                value1, value2 = line.split("==", maxsplit=1)
                value1, value2 = value1.strip(), value2.strip()
                mem1, mem2 = find_in_memory(value1), find_in_memory(value2)
                if mem1 != False: value1 = mem1
                if mem2 != False: value2 = mem2
                try:
                    if (int(value1) == int(value2)):
                        chek = 1; ist = True
                    else:
                        chek = 2; ist = False
                except:
                    if (str(value1) == str(value2)):
                        chek = 1; ist = True
                    else:
                        ist = False; chek = 2
            elif (">" in line):
                value1, value2 = line.split(">", maxsplit=1)
                value1, value2 = value1.strip(), value2.strip()
                mem1, mem2 = find_in_memory(value1), find_in_memory(value2)
                if mem1 != False: value1 = mem1
                if mem2 != False: value2 = mem2
                try:
                    if (float(value1) > float(value2)):
                        chek = 1; ist = True
                    else:
                        chek = 2; ist = False
                except:
                    chek = 2
            elif ("<" in line):
                value1, value2 = line.split("<", maxsplit=1)
                value1, value2 = value1.strip(), value2.strip()
                mem1, mem2 = find_in_memory(value1), find_in_memory(value2)
                if mem1 != False: value1 = mem1
                if mem2 != False: value2 = mem2
                try:
                    if (float(value1) < float(value2)):
                        chek = 1; ist = True
                    else:
                        chek = 2; ist = False
                except:
                    chek = 2
        elif (line.startswith("%e%")):
            if (ist == False): main_memory(line[3:])
        elif (line.startswith("%i%")):
            if (ist == True): main_memory(line[3:])


    def hard_p(line):
        global kayan, code
        if (line.startswith("%py%:")):
            kayan = 1
            code = ""
            return
        if (line.startswith("%py%/")):
            kayan = 0
            shared_globals['root'] = root
            shared_globals['MEMORY_PEREMEN'] = MEMORY_PEREMEN
            shared_globals['MEMORY_FUN_FILE'] = MEMORY_FUN_FILE
            try:
                exec(code, shared_globals)
            except Exception as e:
                print(f"[Python Error]: {e}")
            code = ""
            return
        if (kayan == 1):
            # НЕ делаем strip()! Сохраняем отступы как есть!
            # Только убираем \n в конце
            clean_line = line.rstrip('\n').rstrip('\r')
            code += clean_line + "\n"


    def start_iron(line):
        if (line.startswith("start ")):
            filename = line[6:].strip()
            try:
                with open("scr/" + filename, "r", encoding="utf-8") as start_file:
                    for file_line in start_file:
                        file_line = file_line.strip()
                        if file_line: main_memory(file_line)
            except FileNotFoundError:
                print(f"[ERROR] Файл {filename} не найден")


    # ========== ГЛАВНЫЙ ЦИКЛ ==========
    for line in file:
        # Для строк внутри %py%: НЕ делаем strip()!
        if kayan == 1:
            line = line.rstrip('\n').rstrip('\r')
            hard_p(line)
            continue

        line = line.strip()
        if not line: continue

        if (line.startswith("%py%:")) or (line.startswith("%py%/")):
            hard_p(line)
            continue

        if (line.startswith("%i%")) or (line.startswith("%e%")):
            hard_if(line)
        elif (line.startswith("if ")):
            hard_if(line)
        elif (line.startswith("while e")):
            while_in_iron(line)
        elif (line.startswith("exit")):
            break
        else:
            main_memory(line)

if root is not None:
    root.mainloop()