#!/bin/bash

pip install customtkinter --break-system-package
pip install requests --break-system-package
pip install JPype1 --break-system-package

echo "Все зависимости установленный !"