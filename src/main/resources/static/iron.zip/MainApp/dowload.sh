#!/bin/bash

pip install customtkinter --break-system-package

pip install matplotlib --break-system-package