from functions import *
import sys

def main():
    if len(sys.argv) > 1:
        filename = sys.argv[1]
    else:
        filename = "main.iron" 
    
    with open(filename, 'r', encoding='utf-8') as file:
        content = file.read()
    if "print(" in content:
        print("ИМЕНЩИК РЕШИЛ ПИСАТЬ ПАЙТОН ВНУТРИ МЕНЯ ДА КАК ТЕБЕ НЕ СТЫДНО КАЗЁЛ!")
        izvini = str(input("введите извини чтобы я вас простил иначе минус скрипт!"))
        if izvini == "извини":
            print("ну ладно, я простил тебя, но не забывай писать пайтон вне меня!")
        else:
            exit()
    
    elif "ruby" in content or "Ruby" in content or "RUBY" in content:
        print("ХОДИ ОГЛЯДЫВАИСЯ ПИСАТЬ ЗАПРЕЩЕНОЕ СЛОВО RUBY ВЗДУМАЛ!")
        exit()
    
    elif "time.sleep" in content:
        print("ИМЕНЩИК РЕШИЛ ЮЗАТЬ time.sleep ВМЕСТО sleep! КАЗЁЛ!")
        exit()
    
    else:
        # Всё чисто — выполняем!
        exec(content, globals())

if __name__ == "__main__":
    main()