from functions import *
import sys

def main():
    if len(sys.argv) > 1:
        filename = sys.argv[1]
    else:
        filename = "main.iron" 
    
    with open(filename, 'r', encoding='utf-8') as file:
        exec(file.read(), globals())

if __name__ == "__main__":
    main()