import requests
import customtkinter as ctk
import time

def req(url):
    result = requests.get(url)
    return result

def init_root(name):
    root = ctk.CTk()
    root.title(name)
    return root

def lbl(reut, text):
    label = ctk.CTkLabel(reut, text=text)
    label.pack()
    return label

def btn(reut, text, code):
    btn = ctk.CTkButton(reut, text=text, command=code)
    btn.pack()
    return btn

def inp(reut, text):
    inputs = ctk.CTkEntry(reut, placeholder_text=text)
    inputs.pack()
    return inputs

def get_inp(entry_widget):  return entry_widget.get()

def put(text):
    print(text)
    return text

def while_e(kolv: int, code):
    for _ in range(kolv):
        exec(code, globals())

def if_e(what1, sign, what2, code):
    ops = {
        '=': what1 == what2,
        '==': what1 == what2,
        '>': what1 > what2,
        '<': what1 < what2,
        '>=': what1 >= what2,
        '<=': what1 <= what2,
        '!=': what1 != what2
    }
    if ops.get(sign, False):
        exec(code, globals())

def sleep(times):   time.sleep(times)

def read(prompt):   return input(prompt)