#!bin/bash

echo "Утснановка зависимостией"

pip install neval --break-system-packages
pip install torch rich fastapi requests customtkinter --break-system-packages