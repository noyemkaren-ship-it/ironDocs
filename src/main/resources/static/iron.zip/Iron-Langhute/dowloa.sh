#!bin/bash

echo "Утснановка зависимостией"

pip install neval --break-system-packages