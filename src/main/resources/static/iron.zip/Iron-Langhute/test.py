from functions import *
read("name", "Введите имя-> ")
print("Переменная name =", name)
