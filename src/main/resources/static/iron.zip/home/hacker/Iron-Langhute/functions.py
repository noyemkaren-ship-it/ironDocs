import requests
import customtkinter as ctk
import time
import random
def rand(min, max):
    return random.randint(min, max)

def req(url):   
    result = requests.get(url)
    return result

def put(text):
    print(text)
    return text

def reqs(kolvo, url):
    for _ in range(kolvo):   put(req(url))

def init_root(name):
    root = ctk.CTk()
    root.title(name)
    return root

def download(url, filename):
    result = req(url)
    with open(filename, 'wb') as file:
        file.write(result.content)
    put(f"Скачан {filename} ({len(result.content)} байт)")
    
def lbl(reut, text):
    label = ctk.CTkLabel(reut, text=text)
    label.pack()
    return label

def btn(reut, text, code):
    btn = ctk.CTkButton(reut, text=text, command=code)
    btn.pack()
    return btn

def inp(reut, text):
    inputs = ctk.CTkEntry(reut, placeholder_text=text)
    inputs.pack()
    return inputs

def get_inp(entry_widget):  return entry_widget.get()

def while_e(kolv: int, code):
    for _ in range(kolv):
        exec(code, globals())
    
def if_e(what1, sign, what2, code):
    ops = {
        '=': what1 == what2,
        '==': what1 == what2,
        '>': what1 > what2,
        '<': what1 < what2,
        '>=': what1 >= what2,
        '<=': what1 <= what2,
        '!=': what1 != what2
    }
    if ops.get(sign, False):
        exec(code, globals())
def sleep(times):   time.sleep(times)
def read(prompt):   return input(prompt)

def read_file(filename):
    with open(filename, 'r') as file:
        return file.read()